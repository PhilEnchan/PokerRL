namespace numeral211 {
    inline const int SUITS = 4;
    inline const int RANKS = 10;
    inline const int CARDS_IN_DECK = SUITS * RANKS;
}