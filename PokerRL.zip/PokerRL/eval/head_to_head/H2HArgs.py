# Copyright (c) 2019 Eric Steinberger


class H2HArgs:

    def __init__(self,
                 n_hands):
        self.n_hands = n_hands
